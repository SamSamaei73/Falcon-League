import { createContext } from 'react';

const testContext = createContext();

export default testContext;
