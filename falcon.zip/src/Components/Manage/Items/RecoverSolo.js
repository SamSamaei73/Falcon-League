import React from 'react';
import DetailsPhoto from '../../../Images/aed22.png';


const RecoverSolo = () => {
  return (
    <div className='RoulsSolo'>
        <div className="title">
            <h4>Placement</h4>
            <h4>ID</h4>
            <h4></h4>
            <h4>Score</h4>
            <h4>View Details</h4>
        </div>
        <div className="Row">
            <h4>1</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4><img src={DetailsPhoto} alt="Details"/></h4>
        </div>
        <div className="Row">
            <h4>2</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4><img src={DetailsPhoto} alt="Details"/></h4>
        </div>
        <div className="Row">
            <h4>3</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4>View Details</h4>
        </div>
        <div className="Row">
            <h4>4</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4>View Details</h4>
        </div>
        <div className="Row">
            <h4>5</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4>View Details</h4>
        </div>
        <div className="Row">
            <h4>6</h4>
            <h4>snoopps</h4>
            <h4 className='RecoverSolo'>Recover</h4>
            <h4>243.43</h4>
            <h4>View Details</h4>
        </div>
        {/* <div className="pagination">

        
        <h6>←</h6>
        <h6>1</h6>
        <h6>2</h6>
        <h6>3</h6>
        <h6>4</h6>
        <h6>5</h6>
        <h6>→</h6>
        </div> */}
    </div>
  )
}

export default RecoverSolo