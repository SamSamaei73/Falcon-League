import React from 'react'

const PrizePoolTeam = () => {
  return (
    <div className='PrizePoolTeam'>
        <div className='boxPlace'>
            <div className='box'>
                <h3>Team 1</h3>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
               
            </div>
            <div className='box'>
                <h3>Team 1</h3>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
               
            </div>
            <div className='box'>
                <h3>Team 1</h3>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
               
            </div>
            <div className='box'>
                <h3>Team 1</h3>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
                <div className="rowPlayer">
                    <input type="text" />
                    <input type="text" />
                </div>
               
            </div>
        </div>
        <div className="btnPrize">
            <button>Edit</button>
        </div>
    </div>
  )
}

export default PrizePoolTeam