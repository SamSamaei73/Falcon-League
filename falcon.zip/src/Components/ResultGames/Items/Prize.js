import React from 'react';
import Reload from "../../../Images/Untitled-1.png";


const Prize = () => {
  return (
    <div className='PrizeResult'>
        <h3 className="Reload">
                <img src={Reload} alt="Reload" />
                Last update 10 minutes ago
              </h3>
        <div className="title">
            <h4>Placement</h4>
            <h4>ID</h4>
            <h4></h4>
            <h4></h4>
            <h4>Prize</h4>
        </div>
        <div className="Row">
            <h4>1</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>2</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>3</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>4</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>5</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>6</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>7</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>8</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>9</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
        <div className="Row">
            <h4>10</h4>
            <h4>snoopps</h4>
            <h4></h4>
            <h4></h4>
            <h4>243.43</h4>
        </div>
       
       
    </div>
  )
}

export default Prize