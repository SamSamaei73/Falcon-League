import React from "react";

const TeamSelect = () => {
  return (
    <div className="TeamSelect">
      <div className="title">
        <h4>Match</h4>
        <h4>ID</h4>
        <h4>Team1</h4>
        <h4>Team2</h4>
        <h4>Winner</h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="Row">
        <h4>1-1</h4>
        <h4>snoopps</h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
        <h4>
          <select>
            <option>Blue</option>
            <option>Red</option>
            <option>Yellow</option>
          </select>
        </h4>
      </div>
      <div className="btnStyle">
        <button>Edit</button>
      </div>
   

      {/* <div className="pagination">
        <h6>←</h6>
        <h6>1</h6>
        <h6>2</h6>
        <h6>3</h6>
        <h6>4</h6>
        <h6>5</h6>
        <h6>→</h6>
      </div> */}
    </div>
  );
};

export default TeamSelect;
